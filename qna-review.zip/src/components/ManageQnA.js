"use client";

import { useState, useEffect } from "react";
import { FiTrash2 } from "react-icons/fi";
import toast from "react-hot-toast";

export default function ManageQnA() {
  const [items, setItems] = useState([]);
  const [allItems, setAllItems] = useState([]);
  const [allLoaded, setAllLoaded] = useState(false);
  const [loading, setLoading] = useState(false);
  const [filtered, setFiltered] = useState([]);
  const [badIds, setBadIds] = useState(new Set());
  const [badEmbeddingIds, setBadEmbeddingIds] = useState(new Set());
  // filters
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState("newest");
  const [qualityFilter, setQualityFilter] = useState("all"); // all | good | bad

  // modal
  const [selectedItem, setSelectedItem] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  //total count state
  const [totalCount, setTotalCount] = useState(0);

  //page state
  const [page, setPage] = useState(1);
  const PAGE_SIZE = 20;

  //total pages
  const totalPages = Math.ceil(totalCount / PAGE_SIZE);

  const startIndex = totalCount === 0 ? 0 : (page - 1) * PAGE_SIZE + 1;

  const endIndex =
    totalCount === 0
      ? 0
      : Math.min(startIndex + filtered.length - 1, totalCount);

  /* -----------------------------
       INITIAL LOAD
    ----------------------------- */
  useEffect(() => {
    fetchAudit();
  }, []);

  useEffect(() => {
    if (!search.trim()) {
      fetchPaginated(page);
    }
  }, [page, search]);
  /* -----------------------------
       DATA FETCHING
    ----------------------------- */
  async function fetchPaginated(pageNum = 1) {
    setLoading(true);

    try {
      const res = await fetch(
        `/api/qna/paginated?page=${pageNum}&search=${encodeURIComponent(search)}`,
      );

      const data = await res.json();

      if (data.success) {
        setItems(data.items);
        setFiltered(data.items);
        setTotalCount(data.totalCount);
      }
    } finally {
      setLoading(false);
    }
  }

  async function fetchAll() {
    setLoading(true);

    try {
      const res = await fetch("/api/qna/list");
      const data = await res.json();

      if (data.success) {
        setAllItems(data.items);
        setAllLoaded(true);
      }
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    if (search.trim() && !allLoaded) {
      fetchAll();
    }
  }, [search, allLoaded]);

  async function fetchAudit() {
    const res = await fetch("/api/qna/audit");
    const data = await res.json();

    const bad = new Set(
      (data.items || []).filter((i) => i.content?.broken).map((i) => i.id),
    );

    const badEmbeddings = new Set(
      (data.items || []).filter((i) => !i.embedding?.valid).map((i) => i.id),
    );

    setBadIds(bad);
    setBadEmbeddingIds(badEmbeddings);
  }

  /* -----------------------------
       QUALITY FILTER HANDLING
    ----------------------------- */
  useEffect(() => {
    if (qualityFilter === "all") {
      fetchPaginated(1);
    } else {
      fetchAll();
    }
  }, [qualityFilter]);

  /* -----------------------------
       FILTER + SORT
    ----------------------------- */
  useEffect(() => {
    let data = search.trim() ? [...allItems] : [...items];
    if (search.trim()) {
      const term = search.toLowerCase();

      data = data.filter((i) =>
        (i.question_en || "").toLowerCase().includes(term),
      );
    }
    if (qualityFilter === "content-good") {
      data = data.filter((i) => !badIds.has(i.id));
    }

    if (qualityFilter === "content-bad") {
      data = data.filter((i) => badIds.has(i.id));
    }

    if (qualityFilter === "embedding-good") {
      data = data.filter((i) => !badEmbeddingIds.has(i.id));
    }

    if (qualityFilter === "embedding-bad") {
      data = data.filter((i) => badEmbeddingIds.has(i.id));
    }

    data.sort((a, b) => {
      const tA = new Date(a.createdAt).getTime();
      const tB = new Date(b.createdAt).getTime();
      return sortBy === "newest" ? tB - tA : tA - tB;
    });

    setFiltered(data);
  }, [
    search,
    sortBy,
    qualityFilter,
    items,
    allItems,
    badIds,
    badEmbeddingIds,
  ]); /* -----------------------------
       ACTIONS
    ----------------------------- */
  async function handleDelete(id) {
    if (!confirm("Delete this QnA?")) return;

    const res = await fetch("/api/qna/delete", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ id }),
    });

    const data = await res.json();
    if (data.success) {
      setItems(items.filter((i) => i.id !== id));
      setIsModalOpen(false);
    }
  }

  async function toggleStatus(item) {
    const newStatus = item.status === "inactive" ? "active" : "inactive";

    await fetch("/api/qna/update", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: item.id,
        updates: { status: newStatus },
      }),
    });

    setItems((prev) =>
      prev.map((i) => (i.id === item.id ? { ...i, status: newStatus } : i)),
    );
  }

  // retranslate
  async function translateText(text, targetLang) {
    if (!text) return "";

    const res = await fetch("/api/translate", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text, targetLang }),
    });

    const data = await res.json();
    return data.translated || "";
  }

  //edit QnA saving
  async function saveChanges() {
    if (!selectedItem) return;

    const res = await fetch("/api/qna/update", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        id: selectedItem.id,
        updates: {
          question_en: selectedItem.question_en || "",
          answer_en: selectedItem.answer_en || "",
          question_kn: selectedItem.question_kn || "",
          answer_kn: selectedItem.answer_kn || "",
          editor_note_en: selectedItem.editor_note_en || "",
          editor_note_kn: selectedItem.editor_note_kn || "",
          imam_name: selectedItem.imam_name || "",
          source_title: selectedItem.source_title || "",
          samputa: selectedItem.samputa ?? null,
          sanchike: selectedItem.sanchike ?? null,
        },
      }),
    });

    if (!res.ok) {
      const errorText = await res.text();
      toast.error("Save failed");
      return;
    }

    setItems((prev) =>
      prev.map((i) =>
        i.id === selectedItem.id
          ? {
              ...i,
              question_en: selectedItem.question_en,
              answer_en: selectedItem.answer_en,
              question_kn: selectedItem.question_kn,
              answer_kn: selectedItem.answer_kn,
              editor_note_en: selectedItem.editor_note_en,
              editor_note_kn: selectedItem.editor_note_kn,
              imam_name: selectedItem.imam_name,
              source_title: selectedItem.source_title,
              samputa: selectedItem.samputa,
              sanchike: selectedItem.sanchike,
            }
          : i,
      ),
    );

    setIsModalOpen(false);

    toast.success("Changes saved");
  }

  /* -----------------------------
       RENDER
    ----------------------------- */
  return (
    <div className="space-y-4 text-sm">
      <div className="flex gap-3 mb-6">
        <a
          href="/api/qna/export-html?lang=kn"
          className="px-4 py-2 bg-green-600 text-white rounded-lg"
        >
          Download All Kannada Q&A
        </a>

        <a
          href="/api/qna/export-html?lang=en"
          className="px-4 py-2 bg-blue-600 text-white rounded-lg"
        >
          Download All English Q&A
        </a>
      </div>

      {/* Filters */}
      <div className="flex items-center gap-3 flex-wrap">
        <input
          type="text"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          placeholder="Search English question..."
          className="p-2 border rounded w-64 text-xs"
        />

        <select
          value={qualityFilter}
          onChange={(e) => setQualityFilter(e.target.value)}
          className="p-2 border rounded text-xs"
        >
          <option value="all">All</option>
          <option value="content-good">Content Good</option>
          <option value="content-bad">Content Bad</option>
          <option value="embedding-good">Embedding Good</option>
          <option value="embedding-bad">Embedding Bad</option>
        </select>

        <select
          value={sortBy}
          onChange={(e) => setSortBy(e.target.value)}
          className="p-2 border rounded text-xs"
        >
          <option value="newest">Newest</option>
          <option value="oldest">Oldest</option>
        </select>
        <div className="text-xs text-gray-600">
          Showing {startIndex}–{endIndex} of {totalCount}
        </div>
        {loading && (
          <div className="text-xs text-blue-600 font-medium">
            {search.trim()
              ? `Searching all Q&A records for "${search}"...`
              : "Loading Q&A records..."}
          </div>
        )}
      </div>

      {/* Table */}
      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-xs">
          <thead>
            <tr className="bg-gray-200">
              <th className="p-2 text-left">Question (EN)</th>
              <th className="p-2">Content</th>
              <th className="p-2">Embedding</th>
              <th className="p-2">Lang</th>
              <th className="p-2">Created</th>
              <th className="p-2">Active</th>
              <th className="p-2">Delete</th>
            </tr>
          </thead>

          <tbody>
            {filtered.map((item) => {
              const isBadContent = badIds.has(item.id);
              const isBadEmbedding = badEmbeddingIds.has(item.id);
              const lang =
                item.question_en && item.question_kn
                  ? "EN+KN"
                  : item.question_en
                    ? "EN"
                    : "KN";

              return (
                <tr
                  key={item.id}
                  className="border-b hover:bg-gray-100 cursor-pointer"
                  onClick={() => {
                    setSelectedItem(item);
                    setIsModalOpen(true);
                  }}
                >
                  <td className="p-2 max-w-[420px] truncate font-medium">
                    {item.question_en || (
                      <span className="text-red-600 italic">
                        Missing English translation
                      </span>
                    )}
                  </td>

                  <td className="p-2 text-center">
                    <span
                      className={`px-2 py-0.5 rounded text-xs font-semibold ${
                        isBadContent
                          ? "bg-red-100 text-red-700"
                          : "bg-green-100 text-green-700"
                      }`}
                    >
                      {isBadContent ? "BAD" : "GOOD"}
                    </span>
                  </td>

                  <td className="p-2 text-center">
                    <span
                      className={`px-2 py-0.5 rounded text-xs font-semibold ${
                        isBadEmbedding
                          ? "bg-red-100 text-red-700"
                          : "bg-green-100 text-green-700"
                      }`}
                    >
                      {isBadEmbedding ? "BAD" : "GOOD"}
                    </span>
                  </td>

                  <td className="p-2 text-center font-semibold">{lang}</td>

                  <td className="p-2 text-center">
                    {item.createdAt
                      ? new Date(item.createdAt).toLocaleDateString()
                      : "—"}
                  </td>

                  <td
                    className="p-2 text-center"
                    onClick={(e) => e.stopPropagation()}
                  >
                    <input
                      type="checkbox"
                      checked={item.status !== "inactive"}
                      onChange={() => toggleStatus(item)}
                    />
                  </td>

                  <td
                    className="p-2 text-center"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleDelete(item.id);
                    }}
                  >
                    <FiTrash2 className="text-red-600 hover:text-red-800 text-lg" />
                  </td>
                </tr>
              );
            })}

            {filtered.length === 0 && (
              <tr>
                <td colSpan="6" className="text-center p-3 text-gray-500">
                  No QnA found
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {qualityFilter === "all" && totalPages > 1 && (
        <div className="flex justify-center gap-1 mt-4 flex-wrap">
          <button
            disabled={page === 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            className="px-2 py-1 text-xs border rounded disabled:opacity-40"
          >
            Prev
          </button>

          {Array.from({ length: totalPages }, (_, i) => i + 1)
            .slice(Math.max(0, page - 3), Math.min(totalPages, page + 2))
            .map((p) => (
              <button
                key={p}
                onClick={() => setPage(p)}
                className={`px-2 py-1 text-xs border rounded ${
                  p === page ? "bg-black text-white" : "bg-white"
                }`}
              >
                {p}
              </button>
            ))}

          <button
            disabled={page === totalPages}
            onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
            className="px-2 py-1 text-xs border rounded disabled:opacity-40"
          >
            Next
          </button>
        </div>
      )}

      {/* MODAL */}
      {isModalOpen && selectedItem && (
        <div className="fixed inset-0 bg-black bg-opacity-40 flex items-center justify-center z-50">
          <div className="bg-white rounded-lg shadow-xl max-w-xl w-full max-h-[90vh] overflow-y-auto p-6 space-y-4">
            <h2 className="text-lg font-bold text-[#1D3F9A]">QnA Editor</h2>

            {/* English */}
            <div>
              <h3 className="text-xs font-semibold mb-1">Question (English)</h3>
              <textarea
                className="w-full p-2 border rounded"
                value={selectedItem.question_en || ""}
                onChange={(e) =>
                  setSelectedItem({
                    ...selectedItem,
                    question_en: e.target.value,
                  })
                }
              />
            </div>

            <div>
              <h3 className="text-xs font-semibold mb-1">Answer (English)</h3>
              <textarea
                className="w-full p-2 border rounded h-24"
                value={selectedItem.answer_en || ""}
                onChange={(e) =>
                  setSelectedItem({
                    ...selectedItem,
                    answer_en: e.target.value,
                  })
                }
              />
            </div>

            <hr />

            {/* Kannada */}
            <div>
              <h3 className="text-xs font-semibold mb-1">Question (Kannada)</h3>
              <textarea
                className="w-full p-2 border rounded"
                value={selectedItem.question_kn || ""}
                onChange={(e) =>
                  setSelectedItem({
                    ...selectedItem,
                    question_kn: e.target.value,
                  })
                }
              />
            </div>

            <div>
              <h3 className="text-xs font-semibold mb-1">Answer (Kannada)</h3>
              <textarea
                className="w-full p-2 border rounded h-24"
                value={selectedItem.answer_kn || ""}
                onChange={(e) =>
                  setSelectedItem({
                    ...selectedItem,
                    answer_kn: e.target.value,
                  })
                }
              />
            </div>

            <hr />

            {/* Editor's Notes */}
            <div>
              <h3 className="text-xs font-semibold mb-1">Editor’s Notes</h3>
              <textarea
                className="w-full p-2 border rounded h-20 text-xs"
                placeholder="Optional. Clarifications, usage notes, sources, etc."
                value={selectedItem.editor_note_en || ""}
                onChange={(e) =>
                  setSelectedItem({
                    ...selectedItem,
                    editor_note_en: e.target.value,
                  })
                }
              />
            </div>

            {/*New fields added here  */}
            <div>
              <h3 className="text-xs font-semibold mb-1">Imam Name</h3>
              <input
                className="w-full p-2 border rounded"
                value={selectedItem.imam_name || ""}
                onChange={(e) =>
                  setSelectedItem({
                    ...selectedItem,
                    imam_name: e.target.value,
                  })
                }
              />
            </div>

            <div>
              <h3 className="text-xs font-semibold mb-1">Source Title</h3>
              <input
                className="w-full p-2 border rounded"
                value={selectedItem.source_title || ""}
                onChange={(e) =>
                  setSelectedItem({
                    ...selectedItem,
                    source_title: e.target.value,
                  })
                }
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              <input
                type="text"
                placeholder="Samputa"
                className="p-2 border rounded"
                value={selectedItem.samputa ?? ""}
                onChange={(e) =>
                  setSelectedItem({
                    ...selectedItem,
                    samputa: e.target.value,
                  })
                }
              />
              <input
                type="text"
                placeholder="Sanchike"
                className="p-2 border rounded"
                value={selectedItem.sanchike ?? ""}
                onChange={(e) =>
                  setSelectedItem({
                    ...selectedItem,
                    sanchike: e.target.value,
                  })
                }
              />
            </div>

            <div>
              <h3 className="text-xs font-semibold mb-1">
                Editor’s Note (Kannada)
              </h3>
              <textarea
                className="w-full p-2 border rounded h-20 text-xs"
                placeholder="ಐಚ್ಛಿಕ. ವಿವರಣೆ, ಬಳಕೆಯ ಮಾಹಿತಿ, ಮೂಲಗಳು ಇತ್ಯಾದಿ."
                value={selectedItem.editor_note_kn || ""}
                onChange={(e) =>
                  setSelectedItem({
                    ...selectedItem,
                    editor_note_kn: e.target.value,
                  })
                }
              />
            </div>

            {/* Translation buttons (UI only) */}
            <div className="flex justify-between pt-2">
              <button
                disabled={!selectedItem.question_kn}
                onClick={async () => {
                  const question = await translateText(
                    selectedItem.question_kn,
                    "en",
                  );
                  const answer = await translateText(
                    selectedItem.answer_kn,
                    "en",
                  );

                  setSelectedItem((prev) => ({
                    ...prev,
                    question_en: question,
                    answer_en: answer,
                  }));
                }}
                className="bg-indigo-600 text-white px-4 py-2 rounded text-xs disabled:opacity-40"
              >
                Translate to English
              </button>

              <button
                disabled={!selectedItem.question_en}
                onClick={async () => {
                  const q = await translateText(selectedItem.question_en, "kn");
                  const a = await translateText(
                    selectedItem.answer_en || "",
                    "kn",
                  );

                  setSelectedItem((prev) => ({
                    ...prev,
                    question_kn: q,
                    answer_kn: a,
                  }));
                }}
                className="bg-indigo-600 text-white px-4 py-2 rounded text-xs disabled:opacity-40"
              >
                Translate to Kannada
              </button>
            </div>

            <div className="flex justify-end pt-2">
              <div className="flex justify-end gap-3 pt-2">
                <button
                  onClick={saveChanges}
                  className="bg-green-600 text-white px-4 py-2 rounded hover:bg-green-700"
                >
                  Save Changes
                </button>
                <button
                  onClick={() => setIsModalOpen(false)}
                  className="bg-gray-300 px-4 py-2 rounded hover:bg-gray-400"
                >
                  Close
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
